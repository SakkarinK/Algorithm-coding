import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Scanner;
import java.lang.Math;

public class Grab {
    public static ArrayList<String> ind = new ArrayList<>();
    public static ArrayList<String> allSol = new ArrayList<>();

    public static void Permutation(String pre,String s){
        int n = s.length();
        if(n == 0){
            ind.add(pre);
        }
        else{
            for(int i = 0;i<n;i++){
                Permutation(pre+s.charAt(i),s.substring(0, i)+s.substring(i+1, n));
            }  
        }
    }

    public static int factoria(int n) {
        int fact = 1;
        for (int i = 2; i <= n; i++) {
            fact = fact * i;
        }
        return fact;
    }

    public static void PrePer(String s){
        Permutation("",s);
    }

    public static void bruteForce(char[] data, int j, int K){
        String gp = "";
        for(int a = 0; a < j; a++){
            gp += a + 1;
        }
        PrePer(gp);
        for(int i = 0; i < ind.size(); i++){
            String index = ind.get(i);
            String sol = "";
            for(int a = 0; a < index.length() - 1; a++){
                if(a%2 != 0) continue;
                int gIndValue = Character.getNumericValue(index.charAt(a)) - 1;
                int pIndValue = Character.getNumericValue(index.charAt(a + 1)) - 1;
                char g = data[gIndValue];
                char p = data[pIndValue];               
                if((g=='G'&&p=='P')||(g=='P'&&p=='G')){
                    if(Math.abs(gIndValue - pIndValue) <= K){
                        if(g == 'G' && p == 'P'){
                            sol = sol + "G" + (gIndValue + 1) + "P" + (pIndValue + 1) + "/"; 
                        }
                        else{
                            sol = sol + "G" + (pIndValue + 1) + "P" + (gIndValue + 1 + "/");  
                        }
                    }
                    else{
                        sol = "";
                    }
                }
                else{
                    sol = "";
                }            
            }
            if(sol != "") allSol.add(sol);    
        }
    }

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in); 
        System.out.print("Input : arr[] = ");
        String d = scanner.next();
        System.out.print("K = ");
        int K = scanner.nextInt();
        char in = d.charAt(0);
        char[] data = d.toCharArray();    

        int j = data.length;
        //System.out.println();
        bruteForce(data, j, K);
        ArrayList<String> check = new ArrayList<>();
        for(int t = 0; t < allSol.size(); t++){ 
            boolean redundant = false;
            for(int u = 0; u<check.size(); u++){
                if(check.get(u).equals(allSol.get(t))){
                    redundant = true;
                }
            }
            if(!redundant)
                check.add(allSol.get(t));
        }
        int max = 0;
        int countMax = 0;
        //System.out.println("Brute Force: ");
        for(int e = 0; e < check.size(); e++){
            int n = check.get(e).length() / 4;
            if(max == n){
                countMax +=1;
            }
            if(n > max) {
                max = n;
                countMax = 1;
            }
            //System.out.println(check.get(e) + " Output: " + n);
        }
        System.out.println("BruteForce Output: " + countMax / factoria(max));
        // System.out.println(allSol);
        // System.out.println("Output : " + countMax / factoria(max));
        // System.out.println("Max = " + max);
        // System.out.println("---------------------------------------------------");
        // System.out.println("Grredy: ");
        // simple(data,j,K);
    }
}
