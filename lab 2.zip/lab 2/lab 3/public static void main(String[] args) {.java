public static void main(String[] args) {
        
    Scanner scanner = new Scanner(System.in); 
    System.out.print("Input : arr[] = ");
    String d = scanner.next();
    System.out.print("K = ");
    int K = scanner.nextInt();
    char in = d.charAt(0);
    char[] data = d.toCharArray();    

    int j = data.length;
    //System.out.println();
    bruteForce(data, j, K);
    ArrayList<String> check = new ArrayList<>();
    for(int t = 0; t < allSol.size(); t++){ 
        boolean redundant = false;
        for(int u = 0; u<check.size(); u++){
            if(check.get(u).equals(allSol.get(t))){
                redundant = true;
            }
        }
        if(!redundant)
            check.add(allSol.get(t));
    }
    int max = 0;
    int countMax = 0;
    //System.out.println("Brute Force: ");
    for(int e = 0; e < check.size(); e++){
        int n = check.get(e).length() / 4;
        if(max == n){
            countMax +=1;
        }
        if(n > max) {
            max = n;
            countMax = 1;
        }
        //System.out.println(check.get(e) + " Output: " + n);
    }
    System.out.println("BruteForce Output: " + countMax / factoria(max));
    // System.out.println(allSol);
    // System.out.println("Output : " + countMax / factoria(max));
    // System.out.println("Max = " + max);
    // System.out.println("---------------------------------------------------");
    // System.out.println("Grredy: ");
    // simple(data,j,K);
}