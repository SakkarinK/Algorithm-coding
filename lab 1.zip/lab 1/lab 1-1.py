import timeit
def FindGCD1(m,n):
    m = abs(m)
    n = abs(n)
    if m == 0:
        m = n
    if n == 0:
        n = m
    if n == 0 and m == 0:
        return 0
    t = min(m, n)
    cnt = 0
    while m%t != 0 or n%t != 0:
        cnt += 1
        t -= 1
    return t

m = int(input('Enter m : '))
n = int(input('Enter n : '))
starttime = timeit.default_timer()
print("GCD1 = "+str(FindGCD1((FindGCD1(36,84),120)))+" time used :" + str((timeit.default_timer()-starttime)*10**6))

#print(FindGCD1((FindGCD1(36,84),120)))

def factorization(n):
    p = 2
    f = []
    while n >= p**2:
        if n % p == 0:
            f.append(p)
            n = int(n/p)
        else:
            p += 1
    f.append(n)
    return f

 
def FindGCD2(m,n):
    m = abs(m)
    n = abs(n)
    if m == 0:
        m = n
    if n == 0:
        n = m
    t = 1
    lm = factorization(m)       # n
    ln = factorization(n)       # n
    pre = 0
    for num in lm:              # n
        if num in ln and num != pre:
            pre = num
            a = lm.count(num)
            b = ln.count(num)
            t *= num**min(a, b)
    return t

starttime = timeit.default_timer()
print("GCD2 = "+str(FindGCD2((FindGCD1(36,84),120)))+" time used :" + str((timeit.default_timer()-starttime)*10**6))

#print(FindGCD2((FindGCD2(36,84),120)))

def FindGCD3(m,n):
    m = abs(m)
    n = abs(n)
    if m == 0:
        m = n
    if n == 0:
        n = n
    if m > n:
        if m%n == 0:
            return n
        return FindGCD3(m - n, n)
    elif m == n:
        return m
    else:
        if n%m == 0:
            return m
        return FindGCD3(m, n - m)

starttime = timeit.default_timer()
print("GCD3 = "+str(FindGCD3((FindGCD1(36,84),120)))+" time used :" + str((timeit.default_timer()-starttime)*10**6))

#print(FindGCD3((FindGCD3(36,84),120)))